// Fetch products from the DummyJSON API and display them
const productList = document.getElementById("product-list");
const cartItems = document.getElementById("cart-items");
const cartCount = document.getElementById("cart-count");
const totalAmount = document.getElementById("total-amount");
let cart = [];

// Fetch products and display them
async function fetchProducts() {
    try {
        const response = await fetch("https://dummyjson.com/products");
        const data = await response.json();
        displayProducts(data.products);
    } catch (error) {
        console.error("Error fetching products:", error);
    }
}

// Display products on the page
function displayProducts(products) {
    products.forEach(product => {
        const productDiv = document.createElement("div");
        productDiv.classList.add("product");
        
        productDiv.innerHTML = `
            <img src="${product.thumbnail}" alt="${product.title}">
            <h3>${product.title}</h3>
            <p>${product.description}</p>
            <p>Price: $${product.price}</p>
            <button onclick="addToCart(${product.id}, '${product.title}', ${product.price})">Add to Cart</button>
        `;

        productList.appendChild(productDiv);
    });
}

// Add product to the cart
function addToCart(id, title, price) {
    const product = { id, title, price, quantity: 1 };
    const existingProductIndex = cart.findIndex(item => item.id === id);
    if (existingProductIndex !== -1) {
        cart[existingProductIndex].quantity += 1;
    } else {
        cart.push(product);
    }
    updateCart();
}

// Update cart display
function updateCart() {
    cartItems.innerHTML = "";
    let total = 0;
    cart.forEach(item => {
        total += item.price * item.quantity;
        const itemDiv = document.createElement("div");
        itemDiv.innerHTML = `
            <h3>${item.title}</h3>
            <p>Price: $${item.price}</p>
            <p>Quantity: ${item.quantity}</p>
        `;
        cartItems.appendChild(itemDiv);
    });
    cartCount.textContent = cart.length;
    totalAmount.textContent = `Total: $${total.toFixed(2)}`;
}

// Handle checkout (resets the cart)
document.getElementById("checkout-button").addEventListener("click", () => {
    alert("Thank you for your purchase!");
    cart = [];
    updateCart();
});

// Initialize
fetchProducts();
